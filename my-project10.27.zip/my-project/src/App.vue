<template>
  <div id="app">
    <Home></Home>
    <!-- <router-view/> -->
  </div>
</template>

<script>
import Home from './components/vue-cli/home'
export default {
  name: 'App',
  components:{
    Home
  }
}
</script>

<style>

</style>
