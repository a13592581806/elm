import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Home from './../components/vue-cli/home'
import Msite from './../components/vue-cli/msite'
import Search from './../components/vue-cli/search'
import Order from './../components/vue-cli/order'
import Login from './../components/vue-cli/login'
import Shop from './../components/vue-cli/shop'
import Mine from '../components/mine/mine'
import Download from '../components/mine/download'
import Service from '../components/mine/service'
import Content from '../components/mine/content'
import Member from '../components/mine/member'
import Integral from '../components/mine/integral'
import Detail from '../components/mine/detail'
import Balance from '../components/mine/balance'
import Detail1 from '../components/mine/detail1'
import Shopping from '../components/mine/shopping'
import Customer from '../components/mine/customer'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Msite',
      component: Msite
    },{
      path: '/home',
      name: 'home',
      component: Home,
      children:[
        {
          path: 'msite',
          component: Msite
        },{
          path: 'search',
          component: Search
        },{
          path: 'order',
          component: Order
        },{
          path: 'mine',
          component: Mine
        }
      ]
    },{
      path: '/login',
      name: 'login',
      component: Login
    },{
      path: '/shop/:id',
      name: 'shop',
      component: Shop
    },
    // {
    //   path: 'mine',
    //   name: Mine,
    //   component: Mine
    // },
    {
      path: '/mine/download',
      name: 'Download',
      component: Download
    },
    {
      path: '/mine/service',
      name: 'Service',
      component: Service
    },
    {
      path: '/mine/member',
      name: 'Member',
      component: Member
    },
    {
      path: '/mine/integral',
      name: 'Integral',
      component: Integral
    },
    {
      path: '/mine/integral/detail',
      name: 'Detail',
      component: Detail
    },
    {
      path:'/mine/balance',
      name: 'Balance',
      component: Balance
    },
    {
      path: '/mine/balance/detail1',
      name: 'Detail1',
      component: Detail1
    },
    {
      path: '/mine/shopping',
      name: 'Shopping',
      component: Shopping
    },
    {
      path: '/mine/service/content',
      name: 'Content',
      component: Content
    },
    {
      path: '/mine/service/customer',
      name: 'Customer',
      component: Customer
    }
  ]
})
