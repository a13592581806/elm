<template>
    <div class="detail">
        <div class="detail-nav">
           <img @click='prev' src="./img/left.png">
           <span class="detail-span">积分问题</span>
       </div>
       <div class="detail-div">
           <h3>Q1:怎么获得积分?</h3>
           <ul>
               <li>在线支付的订单将获得订单积分奖励:</li>
               <li>积分将在用户完成评价后</li>
                <li>可获得积分=订单金额x10 (即1元=10点积分)</li>
                <li>订单金额指实际付款金额，不包含活动优惠金额。</li>
                <li>每位用户每天最多可以获得2000积分，体验商家的订单和评价不会增加积分。</li>
           </ul>
           <h3>Q2: 积分用来做什么？</h3>
           <p>可以在积分商城兑换各种礼品。</p>
           <h3>Q3: 礼品兑换很多天了还没有收到，该怎么办？</h3>
           <p>礼品从兑换日起，3个工作日（周末不算）内处理发货，发货后，通常会在3个工作日左右送达。</p>
           <h3 class="h31">Q4: 礼品兑换中的手机充值卡兑换，怎么样进行充值，充值之前会和我电话确认嘛？</h3>
           <p>不会，手机充值卡兑换，是直接充值到您填写的手机号上，充值之前不会和您电话确认，所以您在填写电话的时候，请确认电话是否正确。</p>
       </div>
    </div>
</template>

<script>
export default {
  name: "detail",
  data() {
    return {};
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.detail {
  background: #f5f5f5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.detail-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.detail-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.detail-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.detail-div{
    margin-top: 0.57rem;
    padding: 0.14rem;
    padding-top: 0rem; 
}
.detail-div h3{
    height: 0.58rem;
    line-height: 0.58rem;
    font-size: 0.2rem;
    color: #666666;
}

.detail-div li{
    display: inline-block;
    height: 0.29rem;
    line-height: 0.29rem;
    font-size: 0.18rem;
    color: #999999;
}
.detail-div p{
    display: inline-block;
    height: 0.29rem;
    line-height: 0.29rem;
    font-size: 0.18rem;
    color: #999999;
}
.h31{
    margin-bottom: 0.58rem; 
}
</style>