<template>
    <div class="shopping">
        <div class="shopping-content">
    	    <h3>请重新进入</h3>
    	    <p>请返回后重新进入积分商城~</p>
    	    <img src="./img/重新.png">
        </div>
    </div>
</template>

<script>
export default {
    name:'shopping'
};
</script>

<style scoped>
.shopping {
  background: #f5f5f5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.shopping-content{
    width: 2.3rem;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
}
.shopping-content h3{
    font-size: 0.325rem; 
    color: #1A86D7;
    font-weight: 600;
    margin-bottom: 0.1875rem;
}
.shopping-content p{
    font-size: 0.18rem; 
    color: #A8A8A8;
    margin-bottom: 0.2375rem;
}
.shopping-content img{
   width: 2.2rem;
   height: 2.2rem;
}
</style>
