<template>
    <div class="member">
        <div class="member-nav">
           <img @click='prev' src="./img/left.png">
           <span class="member-span">会员中心</span>
       </div>
    </div>
    
</template>

<script>
export default {
  name: "member",
  data() {
    return {};
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.member {
  background: white;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.member-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: relative;
}
.member-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.member-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
</style>