<template>
    <div class="detail1">
        <div class="detail1-nav">
           <img @click='prev' src="./img/left.png">
           <span class="detail1-span">余额问题</span>
       </div>
       <div class="detail1-div">
           <h3>Q1:使用余额的条件?</h3>
           <p>为了保护账户安全，使用余额前必须先绑定手机号。</p>
           <h3>Q2: 余额可以怎么用？</h3>
           <p>余额可以在饿了么平台上提现，当余额大于等于待支付金额时可以在支持在线支付的商家中进行消费。提现功能将于2016年12月25日00:00全面开放。</p>
           <h3>Q3:我要如何提现？</h3>
           <p>为了保护账户和资金安全，您在提现前需要输入真实姓名和用该姓名开通的银行卡号、选择开户行，并验证已绑定饿了么账号的手机号。每日只能提现1次，每次限额50元。若提现金额超过50元，点击【提现】时系统会提示您已超额，请您修改提现金额。</p>
          <h3>Q4:为什么会提现失败？</h3>
           <p>可能原因有：您的姓名、开户行、银行卡号等信息不匹配；您当日的提现次数和金额超过限制；您的账户存在异常，被风控拦截。</p>
       </div>
    </div>
</template>

<script>
export default {
  name: "detail1",
  data() {
    return {};
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.detail1 {
  background: #f5f5f5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.detail1-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.detail1-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.detail1-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.detail1-div{
  margin-top: 0.57rem;
    padding: 0.14rem;
    padding-top: 0rem; 
}
.detail1-div h3{
    height: 0.58rem;
    line-height: 0.58rem;
    font-size: 0.2rem;
    color: #666666;
}

.detail1-div li{
    display: inline-block;
    height: 0.29rem;
    line-height: 0.29rem;
    font-size: 0.18rem;
    color: #999999;
}
.detail1-div p{
    display: inline-block;
    height: 0.29rem;
    line-height: 0.29rem;
    font-size: 0.18rem;
    color: #999999;
}
</style>