<template>
<div class="integral">
    <div class="integral2">
        <div class="integral-nav">
           <img @click='prev' src="./img/left.png">
           <span class="integral-span">我的积分</span>
       </div>
       <div class="integral-present">
           <div class="integral-present2">
               <div class="present">
                   <span>当前积分</span>
                   <div class="present-div">
                       <img height="14" width="14" src="./img/问号.png">
                       <router-link to="/mine/integral/detail">
                            <span>积分说明</span>
                       </router-link>
                   </div>
               </div>
               <p class="integral-present-p">
                   <span class="shu">0</span>
                   <span class="fen">分</span>
               </p>
               <router-link :to="'#'">
               <div class="integral-present-div">
                   积分兑换商品
               </div>
               </router-link>
           </div>
       </div>  
       <p class="zui">最近30天积分记录</p>
       <div class="integral3">
            <img src="./img/积分.png">
            <p class="wu">最近30天无积分记录</p>
            <p class="zhuan">快去下单赚取大量积分吧</p>
       </div>
       
    </div>
</div>
</template>

<script>
export default {
  name: "integral",
  data() {
    return {};
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.integral {
  background: #f5f5f5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.integral-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.integral-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.integral-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.integral-present {
  margin-top: 0.57rem;
  background: #3190e8;
  padding: 0.09rem;
}
.integral-present2 {
  background: white;
  padding: 0.12rem;
  border-radius: 0.05rem;
}
.present {
  font-size: 0.18rem;
  display: flex;
  justify-content: space-between;
}
.present-div span {
  color: #3190e8;
}
.integral-present-p {
  height: 0.65rem;
  line-height: 0.65rem;
}
.integral-present-p .shu {
  display: inline-block;
  font-size: 0.5rem;
}
.integral-present-p .fen {
  display: inline;
  font-size: 0.2rem;
}
.integral-present-div {
  background: #fe6d47;
  margin-top: 0.293rem;
  color: white;
  height: 0.586rem;
  line-height: 0.586rem;
  text-align: center;
  border-radius: 0.05rem;
  font-size: 0.23rem;
}
.zui {
  height: 0.54rem;
  padding-left: 0.11rem;
  line-height: 0.54rem;
  font-size: 0.18rem;
  color: #999999;
}
.wu {
  height: 0.27rem;
  line-height: 0.27rem;
  text-align: center;
  font-size: 0.2rem;
  color: #999999;
  margin-top: 0.137rem;
}
.zhuan {
  height: 0.22rem;
  line-height: 0.22rem;
  text-align: center;
  font-size: 0.15rem;
  color: #999999;
  margin-top: 0.139rem;
}
.integral3 {
    text-align: center;
    margin-top: 0.29297rem;
}
.integral3 img{
    width:2.38rem;
    height:1.45rem;
}
</style>
