<template>
  <div class="content">
    <div class="content-nav">
        <img @click='prev' src="./img/left.png">
        <span class="content-span">{{title}}</span>
      </div>
      <div class="content-div">
          <p>{{data[tapo]}}</p>
      </div>
  </div>
</template>

<script>
export default {
  name: 'content',
  data(){
    return{
      title:"",
      data: [],
      datas:[]
    }
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  },
  created() {
   this.title=this.$route.params.title;
   this.tapo = this.$route.params.tapo;

    let api = "https://elm.cangdu.org/v3/profile/explain";
    this.$http.get(api).then(data => {
    this.data = data.data;
    for(let k in this.data){
      console.log(this.data[k]);
      this.datas.push(this.data[k]);
    }
    console.log(this.datas);
    this.datas.splice(24,1);
    let data1 = [];
    for(let i=0; i <= this.datas.length; i++){
        if(i % 2 == 0){
          data1.push(this.datas[i]);
        }
    }
    data1.splice(9,2);
    data1.splice(21,1);
    this.data = data1;
    console.log(data1);
    console.log(this.data);
    });
  
  }
};
</script>

<style scoped>
.content {
  background: white;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.content-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.content-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.content-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.content-div{
  margin-top: 0.57rem;
  padding: 0.14rem;
  padding-top: 0rem;
  font-size: 0.27rem;
}
</style>
