<template>
<div class="elm">
    <div class="ele">
      <span>ele.me</span>
      <a href="#">登录|注册</a>
    </div>
    <div class="elem">
    <div class="location">
      <div class="loca">
        <span class="span1">当前定位城市:</span>
        <span class="span2">定位不准时，请在城市列表中选择</span>
      </div>

        <router-link :to="'#'">
          <div class="tion">
              <span class="span3">{{data}}</span>
              <span class="span4"> > </span>
            </div>
        </router-link>
  </div>
  <div class="hot">
      <div class="hot1">
          <span>热门城市</span>
      </div>
      <div class="hot2">
        <ul>
            <li v-for="(item,index) in datas" :key="index">
              <router-link style="text-decoration: none;" :to="'#'">
                <span>{{item.name}}</span>
                </router-link>
            </li>
        </ul>
      </div>
    </div>
    <div class="group">
     <ul>
       <li class="arrange" v-for="(ke,index) in sdic" :key="index">
         <div class="group1">
         <span class="span5">{{ke}} (按字母排列)</span>
         </div>
            <ul class="ul1">
             <li class="li1" v-for="(item,index) in datat[ke]" :key="index">
             <router-link style="text-decoration: none;" :to="'#'">
                   <span class="span6">{{item.name}}</span>
             </router-link>
           </li>
         </ul>

       </li>
     </ul>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "elm",
  data() {
    return {
      data: "",
      datas: [],
      datat: {},
      sdic: []
    };
  },
  created() {
    let api = "https://elm.cangdu.org/v1/cities?type=guess";
    this.$http.get(api).then(data => {
      this.data = data.data.name;
    });
    let api1 = "https://elm.cangdu.org/v1/cities?type=hot";
    this.$http.get(api1).then(datas => {
      this.datas = datas.data;
    });
    let api2 = "https://elm.cangdu.org/v1/cities?type=group";
    this.$http.get(api2).then(datat => {
      let dic = datat.data;
      var sdic = Object.keys(dic).sort();
      this.datat = dic;
      this.sdic = sdic;
    });
  }
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
}
.ele {
  width: 100%;
  height: 0.56rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  position: fixed;
  top: 0px;
  left: 0px;
}
.ele > span {
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 4%;
  transform: translateY(-50%);
}
.ele > a {
  color: white;
  float: right;
  display: inline-block;
  position: absolute;
  top: 50%;
  right: 4%;
  transform: translateY(-50%);
}
.elem {
  width: 100%;
  background: #f5f5f5;
  z-index: 3;
  position: absolute;
  top: 0px;
  left: 0px;
}
.location {
  font-size: 0.13rem;
  background-color: white;
  padding-top: 0.74rem;
}
.loca {
  height: 0.4rem;
  position: relative;
}
.span1 {
  float: left;
  color: #66667f;
  font-weight: 400;
  position: absolute;
  top: 57%;
  left: 3%;
  transform: translateY(-43%);
}
.span2 {
  float: right;
  color: #9f9f9f;
  font-weight: 520;
  position: absolute;
  top: 57%;
  right: 3%;
  transform: translateY(-43%);
}
.tion {
  height: 0.5rem;
  position: relative;
  border-top: 1px solid #e4e4e4;
  border-bottom: 2px solid #e4e4e4;
}
.span3 {
  float: left;
  font-size: 0.23rem;
  color: #3190e8;
  position: absolute;
  top: 57%;
  left: 3%;
  transform: translateY(-43%);
}
.span4 {
  float: right;
  font-size: 0.3rem;
  color: #9f9f9f;
  position: absolute;
  top: 57%;
  right: 3%;
  transform: translateY(-43%);
}
.hot {
  margin-top: 0.14rem;
  background: white;
}
.hot1 {
  width: 100%;
  height: 0.43rem;
  font-size: 0.16rem;
  display: inline-block;
  border-top: 2px solid #e4e4e4;
  border-bottom: 1px solid #e4e4e4;
  position: relative;
}
.hot1 span {
  height: 0.43rem;
  line-height: 0.43rem;
  margin-left: 0.1rem;
  color: #9f9f9f;
  display: block;
  font-weight: 540;
}
.hot2 li {
  width: 24.83%;
  height: 0.5rem;
  background: white;
  list-style-type: none;
  float: left;
  text-align: center;
  border-bottom: 0.009rem solid #e4e4e4;
  border-right: 0.008rem solid #e4e4e4;
}
.hot2 li span {
  width: 100%;
  height: 0.5rem;
  color: #3190e8;
  font-weight: 545;
  line-height: 0.5rem;
  font-size: 0.14rem;
  display: inline-block;
}
.arrange{
  border-bottom: 0.015rem solid #e4e4e4;
}
.group1 {
  width: 100%;
  height: 0.43rem;
  font-size: 0.15rem;
  margin-top: 0.12rem;
  background: white;
  display: inline-block;
  border-top: 2px solid #e4e4e4;
  border-bottom: 1px solid #e4e4e4;
  position: relative;
}

.span5 {
  height: 0.43rem;
  line-height: 0.43rem;
  color: #9f9f9f;
  display: block;
  font-weight: 540;
  margin-left: 0.1rem;
}
.ul1{
  width:100%;
  overflow: hidden;
  background: white;
}
.li1 {
  width: 24.83%;
  height: 0.5rem;
  background: white;
  list-style-type: none;
  float: left;
  text-align: center;
  border-bottom: 0.009rem solid #e4e4e4;
  border-right: 0.008rem solid #e4e4e4;
}
.span6 {
  width: 100%;
  height: 0.5rem;
  color: gray;
  font-weight: 545;
  line-height: 0.5rem;
  font-size: 0.14rem;
  display: inline-block;
  overflow: hidden;
}
</style>
