<template>
  <div class="mine">
      <div class="nav">
        <img src="./img/left.png">
        <span>密码登录</span>
      </div>
  </div>
</template>

<script>
export default {
  name:'mine',
}
</script>

<style scoped>
.nav{
  width: 100%;
  height: 0.8rem;
  background: #5A9FE0
}
</style>

