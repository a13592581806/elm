<template>
  <div class="download">
      <div class="download-nav">
        <img @click='prev' src="./img/left.png">
        <span class="download-span">下载</span>
      </div>
      <div class="download-div">
          <img src="./img/download.png">
          <p>下载饿了么APP</p>
          <div>下载</div>
      </div>
      <router-view></router-view>
  </div>
</template>

<script>
export default {
  name:"download",
  data(){
    return{

    }
  },
  methods:{
       prev(){
        this.$router.go(-1)
        }
    }
}
</script>

<style scoped>
.download {
  background: white;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.download-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.download-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.download-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.download-div {
  margin-top: 0.57rem;
  text-align: center;
}
.download-div img {
  height: 2.25rem;
  border-radius: 0.3rem;
  margin-top: 0.2875rem;
}
.download-div p {
  font-size: 0.24rem;
  margin-top: 0.07rem;
  margin-bottom: 0.288rem;
}
.download-div div {
  height: 0.525rem;
  line-height: 0.525rem;
  color: white;
  background: #4cd964;
  margin-top: 0.14rem;
  margin-left: 0.21rem;
  margin-right: 0.21rem;
  border-radius: 0.07rem;
}
</style>
