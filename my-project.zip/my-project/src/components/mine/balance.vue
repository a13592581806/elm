<template>
<div class="balance">
    <div class="balance2">
        <div class="balance-nav">
           <img @click='prev' src="./img/left.png">
           <span class="balance-span">我的积分</span>
       </div>
       <div class="balance-now">
           <div class="balance-now2">
               <div class="now">
                   <span>当前余额</span>
                   <div class="now-div">
                       <img height="14" width="14" src="./img/问号.png">
                       <router-link to="/mine/balance/detail1">
                            <span>余额说明</span>
                       </router-link>
                   </div>
               </div>
               <p class="balance-now-p">
                   <span class="shu">0.00</span>
                   <span class="fen">元</span>
               </p>
               <router-link :to="'#'">
               <div class="balance-now-div">
                   提现
               </div>
               </router-link>
           </div>
       </div>  
       <p class="jiao">交易明细</p>
       <div class="balance3">
            <img src="./img/积分.png">
            <p class="zan">暂无明细记录</p>
       </div>
       
    </div>
</div>
</template>

<script>
export default {
  name: "balance",
  data() {
    return {};
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.balance {
  background: #f5f5f5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.balance-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.balance-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.balance-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.balance-now {
  margin-top: 0.57rem;
  background: #3190e8;
  padding: 0.09rem;
}
.balance-now2 {
  background: white;
  padding: 0.12rem;
  border-radius: 0.05rem;
}
.now {
  font-size: 0.18rem;
  display: flex;
  justify-content: space-between;
}
.now-div span {
  color: #3190e8;
}
.balance-now-p {
  height: 0.65rem;
  line-height: 0.65rem;
}
.balance-now-p .shu {
  display: inline-block;
  font-size: 0.5rem;
}
.balance-now-p .fen {
  display: inline;
  font-size: 0.2rem;
}
.balance-now-div {
  background: #CCCCCC;
  margin-top: 0.293rem;
  color: white;
  height: 0.586rem;
  line-height: 0.586rem;
  text-align: center;
  border-radius: 0.05rem;
  font-size: 0.23rem;
}
.jiao {
  height: 0.54rem;
  padding-left: 0.11rem;
  line-height: 0.54rem;
  font-size: 0.18rem;
  color: #999999;
}
.zan {
  height: 0.27rem;
  line-height: 0.27rem;
  text-align: center;
  font-size: 0.2rem;
  color: #999999;
  margin-top: 0.137rem;
}
.balance3 {
    text-align: center;
    margin-top: 0.29297rem;
}
.balance3 img{
    width:2.38rem;
    height:1.45rem;
}
</style>
