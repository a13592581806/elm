<template>
  <div class="service">
      <div class="service-nav">
        <img @click='prev' src="./img/left.png">
        <span class="service-span">服务中心</span>
      </div>
      <div class="service-serve">
          <router-link class="service-serve-router1" to="/mine/service/customer">
            <img src="./img/客服.png">
            <span>在线客服</span>
          </router-link>
          <router-link class="service-serve-router2" :to="'#'">
            <img src="./img/客服热线.png">
            <span>在线客服</span>
          </router-link>
      </div>
      <div class="issue">
        <h4>热门问题</h4>
        <ul>
          <li v-for="(k,index) in data" :key="index">
            <router-link :to="{name:'Content',params:{title:k,tapo:index}}">
           <span>{{k}}</span>
            <img src="./img/箭头_右.png">
            </router-link>
          </li>
        </ul>
      </div>
  </div>
</template>

<script>
export default {
  name: "service",
  data() {
    return {
      data: [],
      datas:[]
    };
  },
  methods: {
    prev() {
      this.$router.go(-1);
    }
  },
  created() {
    let api = "https://elm.cangdu.org/v3/profile/explain";
    this.$http.get(api).then(data => {
    this.data = data.data;
    for(let k in this.data){
      console.log(this.data[k]);
      this.datas.push(this.data[k]);
    }
    console.log(this.datas);
    this.datas.splice(24,1);
    let data1 = [];
    for(let i=0; i <= this.datas.length; i++){
        if(i % 2 !== 0){
          data1.push(this.datas[i]);
        }
    }
    data1.splice(8,2);
    this.data = data1;
    console.log(data1);
    console.log(this.data);
    });
  }
};
</script>

<style scoped>
.service {
  background: white;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.service-nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.service-nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.service-span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.service-serve {
  margin-top: 0.57rem;
  display: flex;
  justify-content: space-around;
  text-align: center;
  border-bottom: 0.00023rem solid #f5f5f5;
}
.service-serve-router1 {
  width: 2.4rem;
  height: 1.15rem;
  display: block;
  text-align: center;
  border-right: 0.00023rem solid #f5f5f5;
}
.service-serve-router1 img {
  margin-top: 0.14rem;
}
.service-serve-router1 span {
  margin-top: 0.12rem;
  display: block;
  font-size: 0.2rem;
  font-weight: 300;
  color: #898989;
}
.service-serve-router2 {
  width: 2.4rem;
  display: block;
  text-align: center;
  border-left: 0.00023rem solid #f5f5f5;
}
.service-serve-router2 img {
  margin-top: 0.14rem;
}
.service-serve-router2 span {
  margin-top: 0.12rem;
  display: block;
  font-size: 0.2rem;
  font-weight: 300;
  color: #898989;
}
.issue h4 {
  height: 0.89rem;
  line-height: 0.89rem;
  padding-left: 0.2rem;
  color: #898989;
  font-size: 0.23rem;
}
.issue li a{
  height: 0.54rem;
  line-height: 0.54rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0rem 0.2rem;
  border-top: 0.00023rem solid #f5f5f5;
}
.issue li span{
  font-weight: 300;
  color: #666666;
}
.issue li img{
  width: 0.2rem;
  height:0.3rem;
}
</style>
