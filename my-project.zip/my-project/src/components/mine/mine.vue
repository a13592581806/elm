<template>
  <div class="mine">
      <div class="nav">
        <img src="./img/left.png">
        <span>我的</span>
      </div>
      <router-link :to="'#'">
      <div class="up">
          <img class="up-img1" src="./img/登录.png">
          <div class="up-div">
              <p class="up-p1">登录|注册</p>
              <p class="up-p2">
                 <img class="up-img2" src="./img/手机.png">
                 <span>暂无绑定手机号</span>
              </p>
           </div>
          <img class="up-img3" src="./img/箭头.png" alt="">
      </div>
      </router-link>
      <div class="money">
        <router-link to="/mine/balance">
          <span class="money-span"><b class="money-span-b">0.00</b>元</span>
        </router-link>
         <router-link :to="'#'">
          <span class="money-span"><b class="money-span-c">0</b>个</span>
          </router-link>
          <router-link to="/mine/integral">
          <span class="money-span"><b class="money-span-d">0</b>分</span>
          </router-link>
          <router-link to="/mine/balance">
          <span class="money-span1">我的余额</span>
          </router-link>
          <router-link :to="'#'">
          <span class="money-span1">我的优惠</span>
          </router-link>
          <router-link to="/mine/integral">
          <span class="money-span1">我的积分</span>
          </router-link>
      </div>
      <div class="menu">
        <router-link :to="'#'">
          <div class="menu-order">
            <img class="menu-order-img" src="./img/我的订单.png">
            <div class="menu-order-div">
                <span>我的订单</span>
                <img src="./img/箭头_右.png">
            </div>
          </div>
          </router-link>
          <router-link to="/mine/shopping">
          <div class="menu-store">
            <img class="menu-store-img" src="./img/积分商城.png">
            <div class="menu-store-div">
                <span>积分商城</span>
                <img src="./img/箭头_右.png">
            </div>
          </div>
          </router-link>
          <router-link to="/mine/member">
          <div class="menu-member">
            <img class="menu-member-img" src="./img/皇冠.png">
            <div class="menu-member-div">
                <span>饿了么会员卡</span>
                <img src="./img/箭头_右.png">
            </div>
          </div>
          </router-link>
      </div>
      <div class="serve">
          <router-link :to="{name:'Service'}">
          <div class="serve-centre">
            <img class="serve-centre-img" src="./img/AK-YK方块_fill.png">
            <div class="serve-centre-div">
                <span>服务中心</span>
                <img src="./img/箭头_右.png">
            </div>
          </div>
          </router-link>
          <router-link :to="{name:'Download'}">
          <div class="serve-download">
            <img class="serve-download-img" src="./img/download.png">
            <div class="serve-download-div">
                <span>下载饿了么App</span>
                <img src="./img/箭头_右.png">
            </div>
          </div>
          </router-link>
      </div>
  </div>
</template>

<script>
export default {
  name: "mine"
};
</script>

<style scoped>
.mine {
  background: #F5F5F5;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.nav {
  width: 100%;
  height: 0.57rem;
  font-size: 0.25rem;
  background: #3190e8;
  z-index: 4;
  text-align: center;
  position: relative;
}
.nav > img {
  height: 0.34rem;
  float: left;
  color: white;
  position: absolute;
  top: 50%;
  left: 1.5%;
  transform: translateY(-50%);
}
.nav > span {
  color: white;
  display: inline-block;
  font-weight: 550;
  line-height: 0.56rem;
}
.up {
  height: 0.73rem;
  background: #3190e8;
  padding: 0.193rem 0.18rem;
  overflow: hidden;
}
.up-img1 {
  float: left;
  width: 0.73rem;
}
.up-div {
  width: 3rem;
  float: left;
  color: white;
  padding-top: 0.1rem;
  position: relative;
}
.up-p1 {
  height: 0.32rem;
  font-size: 0.24rem;
  font-weight: 600;
}
.up-p2 {
  height: 0.32rem;
  font-size: 0.16rem;
  margin-top: 0.06rem;
}
.up-p2 span {
  margin-left: 0.24rem;
}
.up-img2 {
  width: 0.24rem;
  position: absolute;
  top: 55%;
  left: 0;
}
.up-img3 {
  float: right;
  width: 0.3rem;
  padding-top: 0.25rem;
}
.money{
  background: white;
}
.money span {
  width: 32.3%;
  display: inline-block;
  text-align: center;
  color: black;
}
.money-span {
  display: inline-block;
  padding: 0.26rem 0rem 0.13rem 0rem;
  font-size: 0.19rem;
  border-right: 0.009rem solid #f2f2f2;
}
.money-span-b {
  font-size: 0.33rem;
  color: #ff9900;
  font-weight: 600;
}
.money-span-c {
  font-size: 0.33rem;
  color: #ff5f3e;
  font-weight: 600;
}
.money-span-d {
  font-size: 0.33rem;
  color: #6ec311;
  font-weight: 600;
}
.money-span1 {
  display: inline-block;
  padding: 0rem 0rem 0.13rem 0rem;
  font-size: 0.19rem;
  border-right: 0.009rem solid #f0f0f0;
}
.menu{
  margin-top: 0.16rem;
  overflow: hidden;
  background: white;
}
.menu-order {
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  position: relative;
}
.menu-order-img {
  height: 0.3rem;
  position: absolute;
  top: 0.11rem;
  left: 0;
}
.menu-store {
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  position: relative;
}
.menu-store-img {
  height: 0.24rem;
  position: absolute;
  top: 0.13rem;
  left: 0;
}
.menu-member {
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  position: relative;
}
.menu-member-img {
  height: 0.3rem;
  position: absolute;
  top: 0.11rem;
  left: 0;
}
.menu-order-div {
  width: 100%;
  float: left;
  color: black;
  font-size: 0.2rem;
  padding: 0.14rem 0.08rem 0.14rem 0.34rem;
  border-bottom: 0.01rem solid #f0f0f0;
}
.menu-order-div img {
  float: right;
  width: 0.26rem;
}
.menu-store-div {
  width: 100%;
  float: left;
  color: black;
  font-size: 0.2rem;
  padding: 0.14rem 0.08rem 0.14rem 0.34rem;
  border-bottom: 0.01rem solid #f0f0f0;
}
.menu-store-div img {
  float: right;
  width: 0.26rem;
}
.menu-member-div {
  width: 100%;
  float: left;
  color: black;
  font-size: 0.2rem;
  padding: 0.14rem 0.08rem 0.14rem 0.34rem;
}
.menu-member-div img {
  float: right;
  width: 0.26rem;
}
.serve{
  margin-top: 0.16rem;
  overflow: hidden;
  background: white;
}
.serve-centre {
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  position: relative;
}
.serve-centre-img {
  height: 0.3rem;
  position: absolute;
  top: 0.11rem;
  left: 0rem;
}
.serve-centre-div {
  width: 100%;
  float: left;
  color: black;
  font-size: 0.2rem;
  padding: 0.14rem 0.08rem 0.14rem 0.34rem;
  border-bottom: 0.01rem solid #f0f0f0;
}
.serve-centre-div img {
  float: right;
  width: 0.26rem;
}
.serve-download {
  overflow: hidden;
  display: flex;
  justify-content: space-around;
  position: relative;
}
.serve-download-img {
  height: 0.15rem;
  position: absolute;
  top: 0.11rem;
  left: 0.1rem;
}
.serve-download-div {
  width: 100%;
  float: left;
  color: black;
  font-size: 0.2rem;
  padding: 0.14rem 0.08rem 0.14rem 0.34rem;
}
.serve-download-div img {
  float: right;
  width: 0.26rem;
}
</style>

