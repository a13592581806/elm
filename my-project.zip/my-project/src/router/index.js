import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Elm from '../components/city/eleMe'
import Mine from '../components/mine/mine'
import Download from '../components/mine/download'
import Service from '../components/mine/service'
import Content from '../components/mine/content'
import Member from '../components/mine/member'
import Integral from '../components/mine/integral'
import Detail from '../components/mine/detail'
import Balance from '../components/mine/balance'
import Detail1 from '../components/mine/detail1'
import Shopping from '../components/mine/shopping'
import Customer from '../components/mine/customer'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/elm',
      name: Elm,
      component: Elm
    },
    {
      path: '/mine',
      name: Mine,
      component: Mine
    },
    {
      path: '/mine/download',
      name: 'Download',
      component: Download
    },
    {
      path: '/mine/service',
      name: 'Service',
      component: Service
    },
    {
      path: '/mine/member',
      name: 'Member',
      component: Member
    },
    {
      path: '/mine/integral',
      name: 'Integral',
      component: Integral
    },
    {
      path: '/mine/integral/detail',
      name: 'Detail',
      component: Detail
    },
    {
      path:'/mine/balance',
      name: 'Balance',
      component: Balance
    },
    {
      path: '/mine/balance/detail1',
      name: 'Detail1',
      component: Detail1
    },
    {
      path: '/mine/shopping',
      name: 'Shopping',
      component: Shopping
    },
    {
      path: '/mine/service/content',
      name: 'Content',
      component: Content
    },
    {
      path: '/mine/service/customer',
      name: 'Customer',
      component: Customer
    }

  ]
})
